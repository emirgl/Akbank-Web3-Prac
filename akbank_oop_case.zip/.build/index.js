class Vehicle {
  hgsNo;
  ownerName;
  balance;
  vehicleType;
  transitionInfos = [];
  constructor(hgsNo, ownerName, balance, vehicleType) {
    this.hgsNo = hgsNo;
    this.ownerName = ownerName;
    this.balance = balance;
    this.vehicleType = vehicleType;
  }
  pay(ticketPrice) {
    this.transitionInfos.push({ hgsNo: this.hgsNo, ownerName: this.ownerName, vehicleType: this.vehicleType });
    this.balance = this.balance - ticketPrice;
  }
}
class Automobile extends Vehicle {
  constructor(hgsNo, ownerName, balance, vehicleType = 1) {
    super(hgsNo, ownerName, balance, vehicleType);
    this.vehicleType = vehicleType;
  }
}
class Minibus extends Vehicle {
  constructor(hgsNo, ownerName, balance, vehicleType = 2) {
    super(hgsNo, ownerName, balance, vehicleType);
    this.vehicleType = vehicleType;
  }
}
class Bus extends Vehicle {
  constructor(hgsNo, ownerName, balance, vehicleType = 3) {
    super(hgsNo, ownerName, balance, vehicleType);
    this.vehicleType = vehicleType;
  }
}
class HgsScanner {
  automobilePrice;
  minibusPrice;
  busPrice;
  records = [];
  constructor() {
    this.automobilePrice = 18;
    this.minibusPrice = 40;
    this.busPrice = 50;
    this.date = new Date();
  }
  payment(driver) {
    let date = new Date();
    if (driver.vehicleType == 1) {
      driver.pay(this.automobilePrice);
      this.records.push({ date, earnedMoney: this.automobilePrice, infos: driver.transitionInfos });
    } else if (driver.vehicleType == 2) {
      driver.pay(this.minibusPrice);
      this.records.push({ date, earnedMoney: this.minibusPrice, infos: driver.transitionInfos });
    } else if (driver.vehicleType == 3) {
      driver.pay(this.busPrice);
      this.records.push({ date, earnedMoney: this.busPrice, infos: driver.transitionInfos });
    }
  }
  takeRecords() {
    return this.records;
  }
}
class Managment extends HgsScanner {
  takeTotal(scanner) {
    var total = 0;
    var arr = [];
    arr = scanner.takeRecords();
    for (let index = 0; index < arr.length; index++) {
      console.log(arr[index]);
      total += arr[index].earnedMoney;
    }
    console.log("Total earning:", total);
  }
}
let driver1 = new Automobile("34XXX34", "Emir", 400);
let driver2 = new Minibus("06YYY06", "Jonah", 1e3);
let driver3 = new Bus("16ZZZ16", "No One", 600);
let hgs = new HgsScanner();
let manager = new Managment();
hgs.payment(driver1);
hgs.payment(driver2);
hgs.payment(driver3);
manager.takeTotal(hgs);
//# sourceMappingURL=index.js.map
